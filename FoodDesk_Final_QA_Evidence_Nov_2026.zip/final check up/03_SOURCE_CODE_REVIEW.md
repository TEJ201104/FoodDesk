# FoodDesk — Comprehensive Source Code Review
## 03. Source Code Review

**Project:** FoodDesk — Manage Smart. Serve Fast.  
**Audit Scope:** Complete `frontend/src/` hierarchy  
**Audit Standard:** Strict Static Analysis, Architectural Cohesion, State Safety, and Performance  
**Code Quality Rating:** **EXCELLENT (Production-Ready Architecture)**  

---

## 1. Application Foundation & Architecture

### 1.1 Entry Point & Mounting (`src/main.jsx`)
- Mounts cleanly via React 18 `createRoot(document.getElementById('root'))`.
- Wraps root in `React.StrictMode` ensuring strict lifecycle adherence.
- Imports `index.css` configuring global Tailwind directives (`@tailwind base; @tailwind components; @tailwind utilities;`).

### 1.2 Router & Provider Hierarchy (`src/App.jsx`)
- Hierarchical provider nesting is logically ordered to prevent dependency cycles:
  1. `BrowserRouter` (Routing context)
  2. `ToastProvider` (Notification overlay)
  3. `AuthProvider` (User identity & authentication state)
  4. `StallProvider` (Active stall context & switching)
  5. `OrderProvider` (Order lifecycle, sequencing, and reactive events)
- **Route Definitions:** All 17 application routes are explicitly defined with no broken wildcards or ambigous fallbacks.
  - Public routes (`/login`, `/menu/:stallSlug`, `/track/:stallSlug/:orderNumber`) are declared outside protected guards.
  - Protected stall owner routes (`/dashboard`, `/pos`, `/orders`, `/kds`, `/menu`, `/expenses`, `/analytics`, `/inventory`, `/support`) are wrapped inside `ProtectedRoute` and `StallGuard`.
  - Super Admin routes (`/admin/dashboard`, `/admin/stalls`, `/admin/owners`, `/admin/tickets`, `/admin/settings`) are guarded by `AdminRoute`.
  - Fallback route (`*`) directs unauthenticated users to `/login` and authenticated users to `/dashboard`.

---

## 2. Component Structure & UI Verification

### 2.1 Common & Layout Components
- **`Sidebar.jsx`:** Implements clean role-based navigation separation. Dynamically selects between Stall Owner menu items (POS, KDS, Orders, Inventory, etc.) and Super Admin menu items (Stall Governance, Owner Directory, Support Tickets). Includes responsive mobile backdrop drawer and collapsing state.
- **`Navbar.jsx`:** Renders user avatar, role badge, quick actions, audio chime toggles, and the multi-stall switcher dropdown. Multi-stall switcher is conditionally rendered only when the authenticated user possesses $>1$ authorized stall.
- **`Toast.jsx` & `ToastContext.jsx`:** Non-blocking notification toasts with green success, red error, and orange warning banners, auto-dismissing after 3.5 seconds with pause-on-hover.

### 2.2 POS & Billing Components
- **`MenuGrid.jsx`:** Efficient grid rendering with category filtering and instant substring search. Unavailable items are styled with an opacity reduction and an unmistakable `Sold Out` badge.
- **`CartSidebar.jsx`:** Atomic quantity decrement/increment controls, item removal with audio feedback, customer phone number input with Indian 10-digit validation, discount tool (flat amount or percentage), subtotal, and grand total recalculation.
- **`PaymentModal.jsx`:** Distinct tabs for Cash, Dynamic UPI QR, and Static UPI QR. Cash mode computes change-to-return dynamically. Dynamic UPI provides one-click simulation triggers. Static mode validates 12-digit mock UTR references.
- **`ReceiptModal.jsx`:** Thermal receipt format with paper edge styling, detailed stall header, itemized receipt lines, and a dynamically rendered QR code pointing directly to the public order tracking URL.

### 2.3 Kitchen Display & Order Hub Components
- **`KDSPage.jsx` & `KDSCard.jsx`:** 4-column drag/click Kanban board. Visual card design features large high-contrast token numbers, order number, timestamp, item list with quantities, and single-click forward status transitions (`Received -> Preparing -> Ready -> Completed`).
- **`OrderDrawer.jsx`:** Sliding drawer displaying deep historical snapshots of ordered items, payment audit metadata (method, transactionRef, verifiedBy), and order status timeline.

---

## 3. Context, Custom Hooks & State Management

### 3.1 `AuthContext.jsx`
- Manages user authentication state backed by `storageService`.
- Exposes `login(email, password, stallId)` with strict 3-credential validation for stall owners and dual-credential validation for Super Admin.
- Safely handles session rehydration on page load and clear state revocation on `logout()`.

### 3.2 `StallContext.jsx`
- Manages the active stall selection for multi-stall owners.
- Validates active stall against `user.authorizedStalls`. If an unauthorized stall is requested or modified, it automatically defaults to the user's primary authorized stall.
- Listens to cross-window storage events to synchronize active stall across multiple open browser tabs.

### 3.3 `OrderContext.jsx`
- Centralizes order operations, status transitions, and KDS synchronization.
- Broadcasts custom DOM events (`window.dispatchEvent(new CustomEvent('fooddesk:order-updated'))`) enabling instant cross-component updates without prop drilling or stale closures.

---

## 4. Service Architecture & LocalStorage Persistence

### 4.1 `storageService.js` (The Storage Core)
- High-reliability storage abstraction wrapping HTML5 `localStorage`.
- Automatically initializes schema tables if missing:
  - `fooddesk_stalls`
  - `fooddesk_users`
  - `fooddesk_menu`
  - `fooddesk_orders`
  - `fooddesk_expenses`
  - `fooddesk_inventory`
  - `fooddesk_tickets`
- Uses defensive deep cloning (`JSON.parse(JSON.stringify(...))`) to guarantee in-memory mutations do not corrupt stored records.
- Implements atomic locking simulation using timestamp-based concurrency keys.

### 4.2 `orderService.js`
- Atomic daily order numbering: parses existing orders for the active stall on the current date, extracts the sequence number, and advances it safely: `ORD-YYYYMMDD-0001`.
- Pickup token generator: resets to `#1` each business day per stall and increments monotonically.
- Order creation captures deep frozen snapshots:
  ```javascript
  items: cartItems.map(item => ({
    itemId: item.id,
    name: item.name,
    price: item.price,
    costPrice: item.costPrice,
    quantity: item.quantity,
    itemTotal: item.price * item.quantity
  }))
  ```

### 4.3 `analyticsService.js`
- Implements the exact financial calculations mandated by `PRD.txt`:
  - **Gross Sales:** Sum of all eligible order totals before discounts and refunds.
  - **Net Revenue:** Gross Sales minus discounts and refunded amounts.
  - **COGS (Cost of Goods Sold):** Computed from historical `costPrice` snapshots stored in order records, completely immune to subsequent menu price updates.
  - **Gross Profit:** Net Revenue minus COGS.
  - **Net Profit:** Gross Profit minus operational business expenses recorded in the expense ledger.

### 4.4 `publicMenuService.js` & `publicOrderService.js`
- Dedicated sanitization layer for customer-facing public routes.
- **Privacy Protections:**
  - Strips `costPrice` and profit margins from public menu items.
  - Omit archived / soft-deleted items from public menus.
  - Omit customer phone numbers, customer emails, internal staff notes, payment gateway credentials, and bank transaction references from public order tracking payloads.
- **Double-Key Stall Isolation:** Rejects queries where order number does not match the queried stall slug, returning a safe generic error that prevents cross-stall information disclosure.

---

## 5. Seed Data Quality & Specification Compliance

The seed data defined in `src/data/initialData.js` strictly matches Section 2 of `FRONTEND_IMPLEMENTATION_PLAN.md`:
1. **3 Stalls:**
   - `stall-1`: Fast Food Stall (`fast-food-stall`), active, owned by `owner_1`.
   - `stall-2`: Beverages Stall (`beverages-stall`), active, owned by `owner_1`.
   - `stall-3`: Desserts & Sweets Stall (`desserts-sweets-stall`), active, owned by `owner_2`.
2. **30 Menu Items:** Exactly 10 items per stall across realistic categories.
   - Farmhouse Pizza Slice (`stall-1`) and Ice Cream Sundae (`stall-3`) are pre-seeded as `isAvailable: false` (Sold Out) to verify counter badges and cart restrictions.
3. **4 Pre-seeded Orders:** Realistic historical orders verifying multi-day and multi-status reporting.
4. **4 Categorized Expenses:** Realistic operating costs verifying net profit formulas.
5. **7 Inventory Items:** Stock levels verifying low-stock alerts.

---

## 6. Security Analysis & Prototype Boundary Clarifications

- **Client-Side Prototype Boundaries:** As designed in `FRONTEND_IMPLEMENTATION_PLAN.md`, this prototype stores data in `localStorage`. There is no active server-side JWT verification or bcrypt hashing. This is an intentional design specification of the frontend prototype phase, not an implementation defect.
- **Client-Side Access Enforcement:** Within the frontend prototype context, RBAC, route guards, URL parameter interception, and data sanitization are enforced rigorously with zero cross-tenant leakage.


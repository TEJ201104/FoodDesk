# FoodDesk — End-to-End Demonstration Workflows
## 05. End-to-End Workflows

**Project:** FoodDesk — Manage Smart. Serve Fast.  
**Audit Scope:** End-to-end user journeys across all roles and system boundaries  
**Methodology:** Automated CDP Headless Browser Orchestration & Multi-Tab Operational Tests  
**Overall Workflow Result:** **ALL 6 WORKFLOWS VERIFIED (100% OPERATIONAL)**  

---

## 1. Workflow A: Stall Owner 1 Complete Operational Lifecycle

### Narrative & Execution Steps
1. **Authentication:** User accesses `/login`, enters `owner1@gmail.com`, password `owner1`, and Stall ID `stall-1`. Clicks **Sign In**.
2. **Dashboard Entry:** System validates credentials and routes to `/dashboard`. Active stall context displays **Fast Food Stall** with today's KPI metrics and recent orders.
3. **POS Order Creation:** Owner navigates to `/pos`. Food grid loads 10 Fast Food items. Owner selects *Veg Burger* (₹70) and *French Fries* (₹70). Adjusts Veg Burger quantity to 2. Subtotal calculates as ₹210.
4. **Discount Application:** Owner applies a ₹10 flat counter discount. Grand total updates to ₹200. Enters customer phone number `9876543210`. Clicks **Place Order**.
5. **Atomic Sequencing:** System generates order `ORD-YYYYMMDD-0001` and pickup token `#1`. Order enters `received` / `awaiting_payment` state.
6. **Payment Processing:** Payment Modal opens. Owner selects **Cash Payment**, enters ₹500 cash tendered. Modal calculates change of ₹300. Owner clicks **Confirm Cash Payment**. Audio chime sounds.
7. **Receipt Generation:** Thermal Receipt modal opens with paper-edge styling, itemized lines, and machine-scannable QR code. Owner clicks **Download PDF Receipt**, generating a valid client-side PDF via `jspdf`.
8. **Kitchen Display Sync:** In KDS (`/kds`), order appears in the **New** column with large token `#1`. Staff clicks **Start Preparing**; card transitions to **Preparing**. Staff clicks **Mark Ready**; card transitions to **Ready**.
9. **Order Management Verification:** In `/orders`, order appears with `Confirmed` and `Ready` status badges. Owner clicks order to inspect frozen historical snapshots in the Order Drawer.
10. **Financial Analytics Reflection:** In `/analytics`, Gross Sales reflect ₹210, Discounts reflect ₹10, Net Revenue reflects ₹200, and COGS reflect ₹100. Gross Profit reflects ₹100.
- **Workflow Result:** **PASS (Seamless End-to-End Execution)**
- **Evidence Reference:** `logs/cross_module_integration.log` (Steps 1–14), `screenshots/live_demo/wf_a_*.png`

---

## 2. Workflow B: Multi-Stall Switching & Tenant Isolation

### Narrative & Execution Steps
1. **Owner Context:** Owner 1 is authenticated. Topbar Navbar detects that Owner 1 possesses 2 authorized stalls (`stall-1` and `stall-2`) and renders the **Stall Switcher** dropdown.
2. **Context Switching:** Owner clicks dropdown and selects **Beverages Stall (`stall-2`)**.
3. **Reactive Data Refresh:**
   - Active stall badge updates to "Beverages Stall".
   - POS workstation instantly reloads, replacing burgers and fries with Cold Coffee, Milkshakes, and Chai.
   - Orders table reloads, displaying only Beverages orders.
   - Expenses and Inventory tables display only beverage ingredients and ledgers.
   - Financial Analytics re-aggregates exclusively for Stall 2.
4. **Switching Back:** Owner switches back to **Fast Food Stall (`stall-1`)**. All Fast Food data restores immediately with zero data corruption or residual state bleed.
- **Workflow Result:** **PASS (Instant & Clean Multi-Tenant Partitioning)**
- **Evidence Reference:** `logs/cross_module_integration.log` (Steps 4–5)

---

## 3. Workflow C: Stall Owner 2 Isolated Scope & Tampering Interception

### Narrative & Execution Steps
1. **Authentication:** Owner 2 logs in using `owner2@gmail.com`, password `owner2`, and Stall ID `stall-3`.
2. **Single-Stall Scoping:** System validates credentials and routes to `/dashboard`. Active stall displays **Desserts & Sweets Stall**.
3. **No Switcher Exposure:** Topbar navbar detects Owner 2 is authorized strictly for 1 stall. The Stall Switcher dropdown is hidden; only a static badge is displayed.
4. **Direct URL Tampering Attempt:** Owner 2 manually enters `/pos?stall=stall-1` or attempts to access Fast Food operational routes.
5. **Guard Interception:** `StallGuard` intercepts the unauthorized stall reference, blocks access, reverts the active stall context to `stall-3`, and triggers a warning toast: *"Unauthorized stall access. Reverting to authorized stall."*
6. **Data Privacy:** Owner 2 is completely unable to view orders, revenue, inventory, or expenses belonging to Stall 1 or Stall 2.
- **Workflow Result:** **PASS (Strict Tenant Boundary Enforcement)**
- **Evidence Reference:** `logs/rbac_and_security.log` §2, `screenshots/live_demo/wf_c_01_owner2_dashboard.png`

---

## 4. Workflow D: Super Admin Platform Oversight & Governance

### Narrative & Execution Steps
1. **Authentication:** User toggles **Super Admin Login** at `/login`, enters `admin@gmail.com` and password `admin`. No Stall ID is required.
2. **Platform Overview:** System routes to `/admin/dashboard`. Admin inspects platform-level metrics: 3 total stalls, total active stalls, platform GMV, total orders, and active users.
3. **Stall Governance:** Admin navigates to `/admin/stalls`. Displays directory of all 3 demo stalls with profile previews, owner contacts, and operational statuses (`active`, `pending`, `suspended`).
4. **Governance Actions:** Admin tests status workflows (Suspending a stall, Reactivating a stall, and reviewing new stall profiles).
5. **Support Ticket Inbox:** Admin navigates to `/admin/tickets`. Centralized inbox displays tickets submitted by stall owners across all stalls.
6. **Resolution Dispatch:** Admin inspects ticket `TCK-20261113-0001` (Printer alignment issue), changes status to `In Progress`, types resolution notes, and transitions ticket to `Resolved`.
- **Workflow Result:** **PASS (Comprehensive Platform Administration)**
- **Evidence Reference:** `logs/cross_module_integration.log` (Steps 26–30), `screenshots/live_demo/wf_d_01_admin_portal.png`

---

## 5. Workflow E: Public Customer Experience (Strictly Read-Only)

### Narrative & Execution Steps
1. **Public Digital Menu:** An unauthenticated visitor opens `/menu/fast-food-stall`.
2. **Catalog Browsing:** Customer browses Fast Food categories (Burgers, Momos, Fries, Pizza). Items display high-quality images, descriptions, and retail selling prices.
3. **Read-Only Verification:** Customer inspects the interface: there is zero shopping cart, no "Add to Cart" button, no order submission form, and no online checkout. The experience is strictly informational.
4. **Availability & Sold Out:** Farmhouse Pizza Slice displays an unmistakable "Sold Out" badge.
5. **Privacy Audit:** Page source and network payloads are inspected: internal cost prices (`costPrice`) and stall profit margins are completely absent from the DOM and state.
6. **Public Order Tracking:** Customer scans the QR code on their thermal receipt or opens `/track/fast-food-stall/ORD-20261112-0001`.
7. **Live Timeline:** Tracker renders a vertical timeline with 5 canonical milestones (`Received`, `Preparing`, `Ready for Pickup`, `Completed`, `Cancelled`).
8. **PII Masking:** Customer phone number, email, and staff transaction IDs are completely hidden.
9. **Cross-Stall Double-Key Isolation:** Customer attempts to track a Beverage order under the Fast Food URL (`/track/fast-food-stall/ORD-20261112-0002`). The tracker returns a safe generic not-found message: *"Order was not found for stall 'Fast Food Stall'"*, revealing zero information about other stalls.
- **Workflow Result:** **PASS (Complete Customer Privacy & Read-Only Integrity)**
- **Evidence Reference:** `logs/public_customer_experience.log`, `screenshots/live_demo/wf_e_*.png`

---

## 6. Workflow F: Persistence, Session Recovery & Error Resilience

### Narrative & Execution Steps
1. **Browser Page Refresh:** Stall Owner refreshes browser while on `/orders` or `/analytics`. Authenticated session, active stall context, and current view state restore instantly without redirecting to `/login`.
2. **Direct Route Navigation:** Stall Owner bookmarks and navigates directly to `/kds` or `/pos`. Route guard verifies active session and loads the requested page directly.
3. **Multi-Tab Synchronization:**
   - Tab 1 has Public Order Tracking open for Order #ORD-20261116-0001.
   - Tab 2 has KDS open. Staff clicks **Mark Ready**.
   - Tab 1 immediately updates to **Ready for Pickup** with audio chime without manual browser reload.
4. **Invalid Input Resilience:** Form submissions with negative prices, empty item names, or malformed customer mobile numbers are validated with inline warnings without page crashes or blank screens.
5. **Non-Existent Routes:** Navigating to an unknown route (e.g. `/unknown-path`) safely redirects authenticated users to `/dashboard` and unauthenticated visitors to `/login`.
- **Workflow Result:** **PASS (High Resilience & Zero Application Crashes)**
- **Evidence Reference:** `logs/browser_runtime_and_console.log`, `logs/cross_module_integration.log`

